package com.shil.portfolio.documents;
import jakarta.annotation.PreDestroy; import org.springframework.stereotype.Service; import java.util.*; import java.util.concurrent.*;
@Service public class DocumentProcessingService{private final Map<UUID,DocumentJob> jobs=new ConcurrentHashMap<>();private final ExecutorService pool=Executors.newFixedThreadPool(Math.max(2,Runtime.getRuntime().availableProcessors()));
 public DocumentJob submit(String fileName){DocumentJob job=new DocumentJob(fileName);jobs.put(job.getId(),job);CompletableFuture.runAsync(()->process(job),pool);return job;}
 public DocumentJob get(UUID id){DocumentJob job=jobs.get(id);if(job==null)throw new NoSuchElementException("Job not found: "+id);return job;}public Collection<DocumentJob> all(){return List.copyOf(jobs.values());}
 private void process(DocumentJob job){try{job.processing();Thread.sleep(250);String extension=job.getFileName().contains(".")?job.getFileName().substring(job.getFileName().lastIndexOf('.')+1):"unknown";job.complete("classified:"+extension.toLowerCase());}catch(InterruptedException e){Thread.currentThread().interrupt();job.fail("processing interrupted");}catch(RuntimeException e){job.fail(e.getMessage());}}
 @PreDestroy void stop(){pool.shutdown();}}
