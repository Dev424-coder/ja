package com.shil.portfolio.documents;
import jakarta.validation.Valid;import jakarta.validation.constraints.NotBlank;import org.springframework.http.HttpStatus;import org.springframework.web.bind.annotation.*;import java.util.*;
@RestController @RequestMapping("/api/document-jobs") public class DocumentController{private final DocumentProcessingService service;public DocumentController(DocumentProcessingService service){this.service=service;}record SubmitRequest(@NotBlank String fileName){}
 @PostMapping @ResponseStatus(HttpStatus.ACCEPTED) DocumentJob submit(@Valid @RequestBody SubmitRequest r){return service.submit(r.fileName());}@GetMapping("/{id}") DocumentJob get(@PathVariable UUID id){return service.get(id);}@GetMapping Collection<DocumentJob> all(){return service.all();}}
