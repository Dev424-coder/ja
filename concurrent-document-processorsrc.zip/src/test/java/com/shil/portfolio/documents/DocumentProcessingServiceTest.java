package com.shil.portfolio.documents;
import org.junit.jupiter.api.Test;import static org.junit.jupiter.api.Assertions.*;
class DocumentProcessingServiceTest{@Test void submitsJob(){var service=new DocumentProcessingService();var job=service.submit("invoice.pdf");assertNotNull(job.getId());assertTrue(service.all().contains(job));service.stop();}}
