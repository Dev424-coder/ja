package com.shil.portfolio.assistant;
import org.springframework.data.jpa.repository.JpaRepository;import java.util.List;
public interface KnowledgeRepository extends JpaRepository<KnowledgeArticle,Long>{List<KnowledgeArticle> findTop5ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(String title,String content);}
