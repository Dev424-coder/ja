package com.shil.portfolio.assistant;
import jakarta.persistence.*;
@Entity public class KnowledgeArticle{@Id @GeneratedValue(strategy=GenerationType.IDENTITY)private Long id;@Column(nullable=false)private String title;@Column(nullable=false,length=4000)private String content;protected KnowledgeArticle(){}public KnowledgeArticle(String title,String content){this.title=title;this.content=content;}public Long getId(){return id;}public String getTitle(){return title;}public String getContent(){return content;}}
