package com.shil.portfolio.assistant;
import java.util.List;
public interface AiProvider{String answer(String question,List<KnowledgeArticle> context);}
