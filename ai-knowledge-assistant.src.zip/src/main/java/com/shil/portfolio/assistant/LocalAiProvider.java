package com.shil.portfolio.assistant;
import org.springframework.stereotype.Component;import java.util.List;import java.util.stream.Collectors;
@Component public class LocalAiProvider implements AiProvider{public String answer(String question,List<KnowledgeArticle> context){if(context.isEmpty())return "No relevant knowledge article was found.";return "Based on the knowledge base: "+context.stream().map(KnowledgeArticle::getContent).collect(Collectors.joining(" "));}}
