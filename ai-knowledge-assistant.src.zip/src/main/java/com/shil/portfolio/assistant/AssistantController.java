package com.shil.portfolio.assistant;
import jakarta.validation.Valid;import jakarta.validation.constraints.NotBlank;import org.springframework.http.HttpStatus;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api") public class AssistantController{private final AssistantService service;public AssistantController(AssistantService service){this.service=service;}record ArticleRequest(@NotBlank String title,@NotBlank String content){}record QuestionRequest(@NotBlank String question){}
 @PostMapping("/articles") @ResponseStatus(HttpStatus.CREATED) KnowledgeArticle add(@Valid @RequestBody ArticleRequest r){return service.add(r.title(),r.content());}
 @PostMapping("/assistant/ask") AssistantService.Answer ask(@Valid @RequestBody QuestionRequest r){return service.ask(r.question());}}
