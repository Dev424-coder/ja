package com.shil.portfolio.assistant;
import org.springframework.stereotype.Service;import java.util.*;
@Service public class AssistantService{private final KnowledgeRepository repository;private final AiProvider provider;public AssistantService(KnowledgeRepository repository,AiProvider provider){this.repository=repository;this.provider=provider;}
 public KnowledgeArticle add(String title,String content){return repository.save(new KnowledgeArticle(title,content));}
 public Answer ask(String question){List<KnowledgeArticle> context=repository.findTop5ByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(question,question);return new Answer(provider.answer(question,context),context.stream().map(KnowledgeArticle::getId).toList());}
 public record Answer(String answer,List<Long> sourceArticleIds){}
}
