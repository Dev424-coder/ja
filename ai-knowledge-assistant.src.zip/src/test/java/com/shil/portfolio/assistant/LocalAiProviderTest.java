package com.shil.portfolio.assistant;
import org.junit.jupiter.api.Test;import java.util.List;import static org.junit.jupiter.api.Assertions.*;
class LocalAiProviderTest{@Test void answersFromContext(){var result=new LocalAiProvider().answer("reset",List.of(new KnowledgeArticle("Password reset","Use the self-service portal.")));assertTrue(result.contains("self-service"));}}
